package com.axolie.editor.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.editor.data.Media

val Purple = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)
val Bg = Color(0xFF0A0A0F)
val Panel = Color(0xFF15151E)
val Panel2 = Color(0xFF1F1F2C)
val Muted = Color(0xFF9A9AB0)
val AxGradient = Brush.horizontalGradient(listOf(Purple, Blue))

@Composable
fun AxolieTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Blue, background = Bg, surface = Panel,
            surfaceVariant = Panel2, onBackground = Color.White, onSurface = Color.White,
            onPrimary = Color.White, error = Color(0xFFFF6B6B),
        ),
        content = content,
    )
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d.%d".format(s / 60, s % 60, (ms % 1000) / 100)
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(if (enabled) AxGradient else Brush.horizontalGradient(listOf(Panel2, Panel2)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = if (enabled) Color.White else Muted)
            Text(text, color = if (enabled) Color.White else Muted, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
    }
}

@Composable
fun Thumb(uri: String?, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = uri?.let { Media.thumb(ctx, it) } }
    Box(modifier.background(Panel2), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.Movie, null, tint = Muted)
    }
}

@Composable
fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String,
    onChange: (Float) -> Unit, onDone: () -> Unit = {},
) {
    Column {
        Row {
            Text(label, fontSize = 12.sp, color = Muted, modifier = Modifier.weight(1f))
            Text(display, fontSize = 12.sp)
        }
        Slider(value = value.coerceIn(range), onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone)
    }
}
