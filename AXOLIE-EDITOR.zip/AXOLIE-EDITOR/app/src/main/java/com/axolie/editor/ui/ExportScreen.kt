@file:OptIn(ExperimentalMaterial3Api::class)

package com.axolie.editor.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.editor.data.*
import com.axolie.editor.export.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.text.DateFormat
import java.util.Date

@Composable
fun ExportScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var project by remember { mutableStateOf<Project?>(null) }
    var res by remember { mutableIntStateOf(1080) }
    var hevc by remember { mutableStateOf(false) }
    var quality by remember { mutableIntStateOf(1) }
    val state by ExportManager.state.collectAsState()
    val history by remember { AppDb.get(ctx).dao().exports() }.collectAsState(emptyList())

    LaunchedEffect(id) {
        project = withContext(Dispatchers.IO) { Repo(ctx).load(id) }
        res = Settings.defaultRes(ctx).first()
    }

    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        // Export works either way; without the permission only the notification is hidden.
        project?.let { ExportService.start(ctx, id, ExportOptions(res, hevc, quality)) }
    }

    val p = project
    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text("Export") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = androidx.compose.ui.graphics.Color.White),
            )
        },
    ) { pad ->
        if (p == null) { Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }; return@Scaffold }

        val mime = if (hevc) ExportPlan.HEVC else ExportPlan.AVC
        val hevcAvailable = remember { DeviceCaps.hasEncoder(ExportPlan.HEVC) }
        val support = remember(p.aspect, hevc) {
            listOf(720, 1080, 2160).associateWith { s ->
                val (w, h) = ExportPlan.dims(p.aspect, s); DeviceCaps.supports(mime, w, h)
            }
        }
        val (w, h) = ExportPlan.dims(p.aspect, res)
        val ok = support[res] == true
        val running = state is ExportState.Running
        val est = ExportPlan.estimateBytes(p.totalMs, w, h, hevc, quality)

        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("${p.name} · ${fmt(p.totalMs)} · ${p.aspect}", color = Muted)

            Section("Resolution") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(720 to "720p", 1080 to "1080p", 2160 to "4K").forEach { (s, l) ->
                        FilterChip(res == s, { res = s }, { Text(l) }, enabled = !running && support[s] == true)
                    }
                }
                val missing = support.filterValues { !it }.keys
                if (missing.isNotEmpty()) Text(
                    missing.joinToString { if (it == 2160) "4K" else "${it}p" } +
                        " unavailable: this device's ${if (hevc) "H.265" else "H.264"} encoder doesn't support that size.",
                    color = Muted, fontSize = 12.sp)
            }
            Section("Codec") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(!hevc, { hevc = false }, { Text("H.264") }, enabled = !running)
                    FilterChip(hevc, { hevc = true }, { Text("H.265 / HEVC") }, enabled = !running && hevcAvailable)
                }
                if (!hevcAvailable) Text("This device has no HEVC encoder.", color = Muted, fontSize = 12.sp)
            }
            Section("Quality") {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Small", "Balanced", "High").forEachIndexed { i, l -> FilterChip(quality == i, { quality = i }, { Text(l) }, enabled = !running) }
                }
            }
            Text("Output: ${w}×$h · about ${"%.0f".format(est / 1_000_000.0)} MB (estimate)\n" +
                "Saved to: Movies/AXOLIE in your gallery\n" +
                "Frame rate follows the source clips (selectable FPS and audio bitrate are not built yet).", color = Muted, fontSize = 12.sp)

            when (val s = state) {
                is ExportState.Running -> ProgressCard(s.percent, s.etaSec, s.projectName)
                is ExportState.Done -> StatusBox("Export finished (${s.label})") {
                    GradientButton("Open video", icon = Icons.Default.PlayArrow) { openVideo(ctx, s.uri) }
                }
                is ExportState.Failed -> StatusBox(s.message, error = true) {}
                ExportState.Cancelled -> StatusBox("Export cancelled.") {}
                ExportState.Idle -> {}
            }

            GradientButton(
                if (running) "Exporting…" else "Start export", Modifier.fillMaxWidth(),
                enabled = !running && ok && p.clips.isNotEmpty(),
            ) {
                if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                else ExportService.start(ctx, id, ExportOptions(res, hevc, quality))
            }
            if (running) Text("You can leave the app: the export keeps running in the background while Android allows it. " +
                "It stops if you force-stop the app, restart the device, or the system kills it.", color = Muted, fontSize = 12.sp)

            if (history.isNotEmpty()) {
                Text("Export history", fontSize = 16.sp)
                history.forEach { e ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.projectName, maxLines = 1)
                            Text("${e.label} · " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(e.createdAt)), color = Muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { openVideo(ctx, e.uri) }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = Muted, fontSize = 12.sp); content()
    }
}

@Composable
private fun ProgressCard(percent: Int, eta: Long?, name: String) {
    val appCtx = LocalContext.current.applicationContext
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel2).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Exporting $name — $percent%")
        LinearProgressIndicator(progress = { percent / 100f }, Modifier.fillMaxWidth())
        Text(eta?.let { "About ${it / 60}m ${it % 60}s remaining" } ?: "Estimating time…", color = Muted, fontSize = 12.sp)
        OutlinedButton(onClick = { ExportService.cancel(appCtx) }) { Text("Cancel export") }
    }
}

@Composable
private fun StatusBox(text: String, error: Boolean = false, extra: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel2).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text, color = if (error) MaterialTheme.colorScheme.error else androidx.compose.ui.graphics.Color.White)
        extra()
    }
}

private fun openVideo(ctx: android.content.Context, uri: String) {
    if (!uri.startsWith("content://")) {
        android.widget.Toast.makeText(ctx, "Saved at: $uri", android.widget.Toast.LENGTH_LONG).show(); return
    }
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        android.widget.Toast.makeText(ctx, "No video player found. Open it from your gallery (Movies/AXOLIE).", android.widget.Toast.LENGTH_LONG).show()
    } catch (e: SecurityException) {
        android.widget.Toast.makeText(ctx, "Couldn't open the file. Find it in your gallery (Movies/AXOLIE).", android.widget.Toast.LENGTH_LONG).show()
    }
}
