package com.axolie.editor.ui

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.axolie.editor.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

data class ProjectCard(val id: String, val name: String, val updatedAt: Long, val clips: Int, val totalMs: Long, val thumb: String?)

class HomeVM(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    val items: StateFlow<List<ProjectCard>?> = repo.dao.projects().map { list ->
        list.map { e ->
            val p = runCatching { AppJson.decodeFromString<Project>(e.json) }.getOrNull()
            ProjectCard(e.id, e.name, e.updatedAt, p?.clips?.size ?: 0, p?.totalMs ?: 0, p?.clips?.firstOrNull()?.uri)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun create(name: String, cb: (String) -> Unit) = viewModelScope.launch {
        val p = Project(name = name.ifBlank { "Untitled project" }); repo.save(p); cb(p.id)
    }
    fun rename(id: String, name: String) = viewModelScope.launch { repo.load(id)?.let { repo.save(it.copy(name = name.ifBlank { it.name })) } }
    fun duplicate(id: String) = viewModelScope.launch { repo.load(id)?.let { repo.save(it.copy(id = newId(), name = it.name + " copy")) } }
    fun delete(id: String) = viewModelScope.launch { repo.dao.delete(id) }
}

private data class Dlg(val kind: String, val id: String? = null, val text: String = "")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (String) -> Unit, onSettings: () -> Unit) {
    val app = LocalContext.current.applicationContext as Application
    val vm: HomeVM = viewModel(factory = viewModelFactory { initializer { HomeVM(app) } })
    val items by vm.items.collectAsState()
    var dlg by remember { mutableStateOf<Dlg?>(null) }

    Scaffold(
        containerColor = Bg,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { dlg = Dlg("new", text = "My video") },
                containerColor = Purple, contentColor = androidx.compose.ui.graphics.Color.White,
                icon = { Icon(Icons.Default.Add, null) }, text = { Text("New project") },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AXOLIE EDITOR", fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("Your projects", color = Muted, fontSize = 13.sp)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings") }
            }
            when {
                items == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                items!!.isEmpty() -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    Icon(Icons.Default.VideoLibrary, null, Modifier.size(64.dp), tint = Purple)
                    Spacer(Modifier.height(12.dp))
                    Text("No projects yet", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Create a project, import clips, add text and export.", color = Muted)
                    Spacer(Modifier.height(16.dp))
                    GradientButton("Create your first project", icon = Icons.Default.Add) { dlg = Dlg("new", text = "My video") }
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(items!!, key = { it.id }) { c -> ProjectRow(c, onOpen = { onOpen(c.id) },
                        onRename = { dlg = Dlg("rename", c.id, c.name) },
                        onDuplicate = { vm.duplicate(c.id) },
                        onDelete = { dlg = Dlg("delete", c.id, c.name) }) }
                }
            }
        }
    }

    dlg?.let { d ->
        when (d.kind) {
            "new", "rename" -> {
                var text by remember(d) { mutableStateOf(d.text) }
                AlertDialog(
                    onDismissRequest = { dlg = null },
                    title = { Text(if (d.kind == "new") "New project" else "Rename project") },
                    text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Name") }) },
                    confirmButton = {
                        TextButton(onClick = {
                            if (d.kind == "new") vm.create(text) { onOpen(it) } else vm.rename(d.id!!, text)
                            dlg = null
                        }) { Text(if (d.kind == "new") "Create" else "Save") }
                    },
                    dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } },
                )
            }
            "delete" -> AlertDialog(
                onDismissRequest = { dlg = null },
                title = { Text("Delete project?") },
                text = { Text("\"${d.text}\" will be removed from this device. Source videos are not deleted.") },
                confirmButton = { TextButton(onClick = { vm.delete(d.id!!); dlg = null }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancel") } },
            )
        }
    }
}

@Composable
private fun ProjectRow(c: ProjectCard, onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onOpen).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(c.thumb, Modifier.size(72.dp, 56.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text("${c.clips} clip${if (c.clips == 1) "" else "s"} · ${fmt(c.totalMs)}", color = Muted, fontSize = 12.sp)
            Text("Edited " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(c.updatedAt)), color = Muted, fontSize = 11.sp)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}
