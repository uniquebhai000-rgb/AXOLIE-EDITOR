@file:OptIn(ExperimentalMaterial3Api::class)

package com.axolie.editor.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolie.editor.data.Settings
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var res by remember { mutableIntStateOf(1080) }
    var cleared by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { res = Settings.defaultRes(ctx).first() }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg, titleContentColor = androidx.compose.ui.graphics.Color.White),
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Default export resolution", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(720 to "720p", 1080 to "1080p", 2160 to "4K").forEach { (s, l) ->
                    FilterChip(res == s, { res = s; scope.launch { Settings.setDefaultRes(ctx, s) } }, { Text(l) })
                }
            }
            Text("If your device can't encode the default size, the Export screen disables it.", color = Muted, fontSize = 11.sp)

            Text("Storage", color = Muted, fontSize = 12.sp)
            Text("Exports are saved to Movies/AXOLIE. Choosing a custom folder isn't built yet.")
            OutlinedButton(onClick = {
                val n = ctx.cacheDir.listFiles()?.count { it.deleteRecursively() } ?: 0
                cleared = "Cleared $n cached item(s)."
            }) { Text("Clear cache") }
            cleared?.let { Text(it, color = Muted, fontSize = 12.sp) }

            Text("Appearance", color = Muted, fontSize = 12.sp)
            Text("AXOLIE EDITOR uses its dark theme. A light theme isn't built yet.")

            Text("Privacy", color = Muted, fontSize = 12.sp)
            Text("Everything runs on your device. This version has no internet permission, no analytics, and no AI service connection. " +
                "Videos are read only from files you pick, and projects store references to them, not copies.")

            Text("About", color = Muted, fontSize = 12.sp)
            Text("AXOLIE EDITOR 0.1.0 (stage 1 MVP)")
        }
    }
}
