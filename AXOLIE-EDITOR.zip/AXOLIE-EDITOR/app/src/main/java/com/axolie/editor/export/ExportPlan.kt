package com.axolie.editor.export

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import com.axolie.editor.data.aspectRatio
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ExportPlan {
    const val AVC = "video/avc"
    const val HEVC = "video/hevc"

    fun dims(aspect: String, shortSide: Int): Pair<Int, Int> {
        val r = aspectRatio(aspect)
        val w: Float
        val h: Float
        if (r >= 1f) { w = shortSide * r; h = shortSide.toFloat() } else { w = shortSide.toFloat(); h = shortSide / r }
        return even(w) to even(h)
    }

    private fun even(v: Float) = ((v / 2f).roundToInt() * 2).coerceAtLeast(2)

    fun videoBitrate(w: Int, h: Int, hevc: Boolean, quality: Int): Int {
        val bpp = doubleArrayOf(0.05, 0.08, 0.12)[quality.coerceIn(0, 2)]
        return (w.toDouble() * h * 30 * bpp * (if (hevc) 0.7 else 1.0)).toInt()
    }

    /** Rough estimate: video bitrate + ~128 kbps audio. */
    fun estimateBytes(totalMs: Long, w: Int, h: Int, hevc: Boolean, quality: Int): Long =
        (videoBitrate(w, h, hevc, quality) + 128_000L) * totalMs / 8000L
}

object DeviceCaps {
    private fun encoders(mime: String): List<MediaCodecInfo> =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(mime, true) }
        }

    fun hasEncoder(mime: String) = encoders(mime).isNotEmpty()

    /** True if any encoder for [mime] reports support for this frame size at 30 fps. */
    fun supports(mime: String, w: Int, h: Int): Boolean = encoders(mime).any { info ->
        runCatching {
            val vc = info.getCapabilitiesForType(mime).videoCapabilities ?: return@runCatching false
            val a = max(w, h); val b = min(w, h)
            (vc.isSizeSupported(w, h) || vc.isSizeSupported(h, w) || vc.isSizeSupported(a, b)) &&
                vc.areSizeAndRateSupported(w, h, 30.0).or(vc.areSizeAndRateSupported(h, w, 30.0))
        }.getOrDefault(false)
    }
}
