package com.axolie.editor.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

object Settings {
    private val RES = intPreferencesKey("default_res")
    fun defaultRes(ctx: Context): Flow<Int> = ctx.dataStore.data.map { it[RES] ?: 1080 }
    suspend fun setDefaultRes(ctx: Context, v: Int) { ctx.dataStore.edit { it[RES] = v } }
}
