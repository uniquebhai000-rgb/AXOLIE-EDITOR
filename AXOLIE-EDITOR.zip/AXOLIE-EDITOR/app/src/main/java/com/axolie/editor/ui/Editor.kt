@file:OptIn(ExperimentalMaterial3Api::class)

package com.axolie.editor.ui

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.axolie.editor.data.*
import kotlinx.coroutines.delay

private data class TextStyleDef(val name: String, val color: Long, val bg: Long, val bold: Boolean, val italic: Boolean = false)

private val TEXT_STYLES = listOf(
    TextStyleDef("Classic", 0xFFFFFFFF, 0x00000000, true),
    TextStyleDef("Gaming", 0xFF22D3EE, 0xCC0A0A0F, true),
    TextStyleDef("Neon", 0xFFFF2BD6, 0x00000000, true),
    TextStyleDef("Subtitle", 0xFFFFFFFF, 0x99000000, false),
    TextStyleDef("Caption", 0xFFFACC15, 0xCC000000, true),
    TextStyleDef("Cinematic", 0xFFE5E7EB, 0x00000000, false, true),
)
private val PALETTE = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFACC15, 0xFFEF4444, 0xFF22D3EE, 0xFF8B5CF6, 0xFF3B82F6, 0xFF22C55E, 0xFFFF2BD6).map { it.toInt() }
private val BG_PALETTE = listOf(0x00000000L, 0xCC000000L, 0xCC8B5CF6L, 0xCCFACC15L, 0xCC3B82F6L).map { it.toInt() }

@Composable
fun EditorScreen(id: String, onBack: () -> Unit, onExport: () -> Unit) {
    val app = LocalContext.current.applicationContext as Application
    val vm: EditorVM = viewModel(key = "editor_$id", factory = viewModelFactory { initializer { EditorVM(app, id) } })
    val p by vm.project.collectAsState()
    val cur = p
    if (cur == null) {
        Box(Modifier.fillMaxSize().background(Bg), Alignment.Center) { CircularProgressIndicator() }
    } else {
        EditorContent(vm, cur, onBack = { vm.flush(); onBack() }, onExport = { vm.flush(); onExport() })
    }
}

@Composable
private fun EditorContent(vm: EditorVM, p: Project, onBack: () -> Unit, onExport: () -> Unit) {
    val ctx = LocalContext.current
    val canUndo by vm.canUndo.collectAsState()
    val canRedo by vm.canRedo.collectAsState()
    val busy by vm.busy.collectAsState()
    val msg by vm.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selClip by rememberSaveable { mutableIntStateOf(0) }
    var selText by rememberSaveable { mutableStateOf<String?>(null) }
    var zoom by rememberSaveable { mutableFloatStateOf(40f) }
    var playhead by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)
    LaunchedEffect(msg) { msg?.let { snackbar.showSnackbar(it); vm.message.value = null } }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addVideos(it) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::addMusic) }

    // ---- Player ----
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    val latest by rememberUpdatedState(p)

    val sig = p.clips.map { Triple(it.uri, it.trimStartMs, it.trimEndMs) }
    LaunchedEffect(sig) {
        delay(150) // debounce while trimming
        val keep = playhead
        if (p.clips.isEmpty()) { player.clearMediaItems(); return@LaunchedEffect }
        player.setMediaItems(p.clips.map {
            MediaItem.Builder().setUri(it.uri).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(it.trimStartMs).setEndPositionMs(it.trimEndMs).build()
            ).build()
        })
        player.prepare()
        val (i, off) = p.locate(keep.coerceAtMost(p.totalMs))
        player.seekTo(i, off)
    }
    LaunchedEffect(player) {
        while (true) {
            val pr = latest
            if (pr.clips.isNotEmpty()) {
                val i = player.currentMediaItemIndex.coerceIn(0, pr.clips.lastIndex)
                val c = pr.clips[i]
                if (player.playbackParameters.speed != c.speed) player.setPlaybackSpeed(c.speed)
                player.volume = c.volume.coerceIn(0f, 1f)
                playhead = pr.startOf(i) + (player.currentPosition.coerceAtLeast(0) / c.speed).toLong()
            }
            playing = player.isPlaying
            delay(50)
        }
    }
    fun seekTo(ms: Long) {
        if (p.clips.isEmpty()) return
        val (i, off) = p.locate(ms.coerceIn(0, p.totalMs))
        player.seekTo(i, off); playhead = ms
    }
    fun togglePlay() {
        if (p.clips.isEmpty()) return
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_ENDED) seekTo(0)
            player.play()
        }
    }

    Scaffold(containerColor = Bg, snackbarHost = { SnackbarHost(snackbar) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // Top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text(p.name, Modifier.weight(1f), maxLines = 1, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = vm::undo, enabled = canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
                IconButton(onClick = vm::redo, enabled = canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
                GradientButton("Export", enabled = p.clips.isNotEmpty(), onClick = onExport,
                    modifier = Modifier.padding(end = 8.dp))
            }

            // Preview
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).padding(8.dp), Alignment.Center) {
                val r = aspectRatio(p.aspect)
                val fw = if (maxWidth / maxHeight > r) maxHeight * r else maxWidth
                val fh = fw / r
                Box(Modifier.size(fw, fh).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
                    if (p.clips.isEmpty()) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.VideoLibrary, null, tint = Purple, modifier = Modifier.size(40.dp))
                            Spacer(Modifier.height(8.dp))
                            GradientButton(if (busy) "Importing…" else "Import videos", icon = Icons.Default.Add, enabled = !busy) {
                                pickVideo.launch(arrayOf("video/*"))
                            }
                        }
                    } else {
                        val c = p.clips.getOrNull(selClip)
                        AndroidView(
                            modifier = Modifier.fillMaxSize().graphicsLayer {
                                // Approximate preview of rotate/flip for the selected clip only
                                rotationZ = (c?.rotation ?: 0).toFloat(); scaleX = if (c?.flipH == true) -1f else 1f
                            },
                            factory = { PlayerView(it).apply {
                                useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM; this.player = player
                            } },
                        )
                    }
                    val density = LocalDensity.current
                    p.texts.forEach { t ->
                        val a = t.alphaAt(playhead)
                        val selected = t.id == selText && tab == 1
                        val shown = if (a > 0f) a else if (selected) 0.35f else 0f
                        if (shown > 0f) {
                            Text(
                                t.text, Modifier.align(BiasAlignment(t.posX * 2 - 1, t.posY * 2 - 1))
                                    .graphicsLayer { alpha = shown }
                                    .background(Color(t.bgColor))
                                    .then(if (selected) Modifier.border(1.dp, Color.White) else Modifier),
                                color = Color(t.color),
                                fontSize = with(density) { (t.sizeFrac * fh.toPx()).toSp() },
                                fontWeight = if (t.bold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (t.italic) FontStyle.Italic else FontStyle.Normal,
                            )
                        }
                    }
                    if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
                }
            }

            // Transport + scrub
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = ::togglePlay, enabled = p.clips.isNotEmpty()) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
                }
                Text(fmt(playhead) + " / " + fmt(p.totalMs), fontSize = 12.sp, color = Muted)
                Slider(
                    value = playhead.toFloat().coerceIn(0f, maxOf(1f, p.totalMs.toFloat())),
                    onValueChange = { player.pause(); seekTo(it.toLong()) },
                    valueRange = 0f..maxOf(1f, p.totalMs.toFloat()),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    enabled = p.clips.isNotEmpty(),
                )
            }

            // Timeline
            if (p.clips.isNotEmpty()) {
                Timeline(p, zoom, playhead, selClip, selText,
                    onClip = { selClip = it; tab = 0 },
                    onText = { selText = it; tab = 1 })
                Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ZoomIn, null, tint = Muted, modifier = Modifier.size(16.dp))
                    Slider(zoom, { zoom = it }, valueRange = 15f..150f, modifier = Modifier.height(24.dp).padding(horizontal = 8.dp))
                }
            }

            // Tool tabs
            Row(Modifier.fillMaxWidth().background(Panel).padding(vertical = 4.dp), Arrangement.SpaceEvenly) {
                listOf(
                    Icons.Default.ContentCut to "Clips", Icons.Default.TextFields to "Text", Icons.Default.MusicNote to "Audio",
                    Icons.Default.AutoFixHigh to "Filters", Icons.Default.AspectRatio to "Canvas",
                ).forEachIndexed { i, (ic, label) ->
                    Column(Modifier.clip(RoundedCornerShape(10.dp)).clickable { tab = i }.padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(ic, label, tint = if (tab == i) Purple else Muted)
                        Text(label, fontSize = 10.sp, color = if (tab == i) Purple else Muted)
                    }
                }
            }
            Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).background(Panel).verticalScroll(rememberScrollState()).padding(12.dp)) {
                when (tab) {
                    0 -> ClipPanel(vm, p, selClip.coerceIn(0, maxOf(0, p.clips.lastIndex)), playhead, busy,
                        onSelect = { selClip = it }, onImport = { pickVideo.launch(arrayOf("video/*")) })
                    1 -> TextPanel(vm, p, selText, playhead, onSelect = { selText = it })
                    2 -> AudioPanel(vm, p, onAdd = { pickAudio.launch(arrayOf("audio/*")) })
                    3 -> FilterPanel(vm, p)
                    else -> CanvasPanel(vm, p)
                }
            }
        }
    }
}

@Composable
private fun Timeline(
    p: Project, zoom: Float, playhead: Long, selClip: Int, selText: String?,
    onClip: (Int) -> Unit, onText: (String) -> Unit,
) {
    Box(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Column {
            Row(Modifier.height(52.dp)) {
                p.clips.forEachIndexed { i, c ->
                    val shape = RoundedCornerShape(6.dp)
                    Box(
                        Modifier.width((c.effectiveMs / 1000f * zoom).dp).fillMaxHeight().clip(shape)
                            .border(if (i == selClip) 2.dp else 0.dp, Purple, shape).clickable { onClip(i) }
                    ) {
                        Thumb(c.uri, Modifier.fillMaxSize())
                        Text(fmt(c.effectiveMs), Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(2.dp), fontSize = 9.sp)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.height(22.dp).fillMaxWidth()) {
                p.texts.forEach { t ->
                    Box(
                        Modifier.offset(x = (t.startMs / 1000f * zoom).dp).width((t.durationMs / 1000f * zoom).dp.coerceAtLeast(28.dp)).fillMaxHeight()
                            .clip(RoundedCornerShape(5.dp)).background(if (t.id == selText) Purple else Color(0xFF4C3A8F)).clickable { onText(t.id) }
                    ) { Text(t.text, maxLines = 1, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp)) }
                }
            }
            Spacer(Modifier.height(4.dp))
            p.music.forEach { m ->
                Box(Modifier.width((minOf(m.durationMs, p.totalMs) / 1000f * zoom).dp).height(16.dp).padding(bottom = 2.dp)
                    .clip(RoundedCornerShape(5.dp)).background(Blue.copy(alpha = 0.55f))) {
                    Text("♪ " + m.name, fontSize = 9.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
        }
        Box(Modifier.offset(x = (playhead / 1000f * zoom).dp).width(2.dp).height(100.dp).background(Color.White))
    }
}

@Composable
private fun ToolBtn(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = if (enabled) Color.White else Muted)
        Text(label, fontSize = 10.sp, color = if (enabled) Color.White else Muted)
    }
}

@Composable
private fun ClipPanel(vm: EditorVM, p: Project, sel: Int, playhead: Long, busy: Boolean, onSelect: (Int) -> Unit, onImport: () -> Unit) {
    val c = p.clips.getOrNull(sel)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        ToolBtn(Icons.Default.Add, "Import", !busy, onImport)
        ToolBtn(Icons.Default.ContentCut, "Split", c != null) {
            val (i, off) = p.locate(playhead)
            val cl = p.clips[i]; val at = cl.trimStartMs + off
            if (at <= cl.trimStartMs + 200 || at >= cl.trimEndMs - 200) vm.message.value = "Move the playhead inside a clip (not at its edge) to split."
            else {
                vm.edit { pr -> pr.copy(clips = pr.clips.toMutableList().apply {
                    removeAt(i); add(i, cl.copy(trimEndMs = at)); add(i + 1, cl.copy(id = newId(), trimStartMs = at))
                }) }
                onSelect(i)
            }
        }
        ToolBtn(Icons.Default.ContentCopy, "Duplicate", c != null) {
            vm.edit { pr -> pr.copy(clips = pr.clips.toMutableList().apply { add(sel + 1, c!!.copy(id = newId())) }) }
        }
        ToolBtn(Icons.Default.Delete, "Delete", c != null) {
            vm.edit { pr -> pr.copy(clips = pr.clips.filterIndexed { i, _ -> i != sel }) }
            onSelect((sel - 1).coerceAtLeast(0))
        }
        ToolBtn(Icons.AutoMirrored.Filled.ArrowBack, "Move ←", c != null && sel > 0) {
            vm.edit { pr -> pr.copy(clips = pr.clips.toMutableList().apply { add(sel - 1, removeAt(sel)) }) }; onSelect(sel - 1)
        }
        ToolBtn(Icons.Default.ArrowForward, "Move →", c != null && sel < p.clips.lastIndex) {
            vm.edit { pr -> pr.copy(clips = pr.clips.toMutableList().apply { add(sel + 1, removeAt(sel)) }) }; onSelect(sel + 1)
        }
        ToolBtn(Icons.Default.RotateRight, "Rotate", c != null) { vm.edit { it.mapClip(sel) { x -> x.copy(rotation = (x.rotation + 90) % 360) } } }
        ToolBtn(Icons.Default.Flip, "Flip", c != null) { vm.edit { it.mapClip(sel) { x -> x.copy(flipH = !x.flipH) } } }
    }
    if (c == null) {
        Text("Import videos to start editing.", color = Muted, modifier = Modifier.padding(top = 8.dp)); return
    }
    Text(c.name, fontSize = 12.sp, color = Muted, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
    Text("Trim", fontSize = 12.sp, color = Muted)
    RangeSlider(
        value = c.trimStartMs.toFloat()..c.trimEndMs.toFloat(),
        onValueChange = { r ->
            if (r.endInclusive - r.start >= 300f)
                vm.live { it.mapClip(sel) { x -> x.copy(trimStartMs = r.start.toLong(), trimEndMs = r.endInclusive.toLong()) } }
        },
        valueRange = 0f..c.durationMs.toFloat(), onValueChangeFinished = vm::commit,
    )
    Text("Speed", fontSize = 12.sp, color = Muted)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 4f).forEach { s ->
            FilterChip(c.speed == s, { vm.edit { it.mapClip(sel) { x -> x.copy(speed = s) } } }, { Text("${s}x") })
        }
    }
    LabeledSlider("Volume", c.volume, 0f..2f, "${(c.volume * 100).toInt()}%",
        { v -> vm.live { it.mapClip(sel) { x -> x.copy(volume = v) } } }, vm::commit)
}

@Composable
private fun TextPanel(vm: EditorVM, p: Project, selId: String?, playhead: Long, onSelect: (String?) -> Unit) {
    val t = p.texts.find { it.id == selId }
    val total = maxOf(1000L, p.totalMs).toFloat()
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        GradientButton("Add text", icon = Icons.Default.Add) {
            val n = TextLayer(startMs = playhead.coerceAtMost(maxOf(0L, p.totalMs - 500)))
            vm.edit { it.copy(texts = it.texts + n) }; onSelect(n.id)
        }
        p.texts.forEach { x -> FilterChip(x.id == selId, { onSelect(x.id) }, { Text(x.text.take(12), maxLines = 1) }) }
    }
    if (t == null) {
        Text(if (p.texts.isEmpty()) "Add a text layer, then edit its style, position and timing."
        else "Select a text layer above.", color = Muted, modifier = Modifier.padding(top = 8.dp)); return
    }
    fun upd(f: (TextLayer) -> TextLayer) = vm.live { it.mapText(t.id, f) }
    OutlinedTextField(t.text, { v -> upd { it.copy(text = v) } }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Text") })

    Text("Style presets", fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 8.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(TEXT_STYLES) { s ->
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A2A3A))
                    .border(if (t.style == s.name) 2.dp else 0.dp, Purple, RoundedCornerShape(10.dp))
                    .clickable { vm.edit { it.mapText(t.id) { x -> x.copy(style = s.name, color = s.color.toInt(), bgColor = s.bg.toInt(), bold = s.bold, italic = s.italic) } } }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) { // live preview of each style
                Text(s.name, color = Color(s.color), fontSize = 14.sp, fontWeight = if (s.bold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (s.italic) FontStyle.Italic else FontStyle.Normal, modifier = Modifier.background(Color(s.bg)))
            }
        }
    }
    Text("Colour", fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PALETTE.forEach { c -> Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c))
            .border(if (t.color == c) 2.dp else 1.dp, if (t.color == c) Purple else Muted, CircleShape).clickable { vm.edit { it.mapText(t.id) { x -> x.copy(color = c) } } }) }
    }
    Text("Background", fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        BG_PALETTE.forEach { c -> Box(Modifier.size(30.dp).clip(CircleShape).background(if (c == 0) Color(0xFF2A2A3A) else Color(c))
            .border(if (t.bgColor == c) 2.dp else 1.dp, if (t.bgColor == c) Purple else Muted, CircleShape).clickable { vm.edit { it.mapText(t.id) { x -> x.copy(bgColor = c) } } }) {
            if (c == 0) Icon(Icons.Default.Close, "None", Modifier.align(Alignment.Center).size(14.dp), tint = Muted)
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
        FilterChip(t.bold, { vm.edit { it.mapText(t.id) { x -> x.copy(bold = !x.bold) } } }, { Text("Bold") })
        FilterChip(t.italic, { vm.edit { it.mapText(t.id) { x -> x.copy(italic = !x.italic) } } }, { Text("Italic") })
        listOf("None", "Fade").forEach { a -> FilterChip(t.animation == a, { vm.edit { it.mapText(t.id) { x -> x.copy(animation = a) } } }, { Text(if (a == "None") "No animation" else "Fade in/out") }) }
    }
    LabeledSlider("Size", t.sizeFrac, 0.03f..0.2f, "${(t.sizeFrac * 100).toInt()}%", { v -> upd { it.copy(sizeFrac = v) } }, vm::commit)
    LabeledSlider("Horizontal position", t.posX, 0.05f..0.95f, "${(t.posX * 100).toInt()}%", { v -> upd { it.copy(posX = v) } }, vm::commit)
    LabeledSlider("Vertical position", t.posY, 0.05f..0.95f, "${(t.posY * 100).toInt()}%", { v -> upd { it.copy(posY = v) } }, vm::commit)
    LabeledSlider("Opacity", t.opacity, 0.1f..1f, "${(t.opacity * 100).toInt()}%", { v -> upd { it.copy(opacity = v) } }, vm::commit)
    LabeledSlider("Start", t.startMs.toFloat(), 0f..total, fmt(t.startMs), { v -> upd { it.copy(startMs = v.toLong()) } }, vm::commit)
    LabeledSlider("Duration", t.durationMs.toFloat(), 500f..maxOf(1000f, total), fmt(t.durationMs), { v -> upd { it.copy(durationMs = v.toLong()) } }, vm::commit)
    TextButton(onClick = { vm.edit { it.copy(texts = it.texts.filter { x -> x.id != t.id }) }; onSelect(null) }) {
        Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Delete text layer")
    }
}

@Composable
private fun AudioPanel(vm: EditorVM, p: Project, onAdd: () -> Unit) {
    GradientButton("Add music / audio file", icon = Icons.Default.MusicNote, onClick = onAdd)
    if (p.music.isEmpty()) Text("Pick an audio file to use as background music. It is trimmed to the video length on export.", color = Muted, modifier = Modifier.padding(top = 8.dp))
    p.music.forEach { m ->
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.name, maxLines = 1, fontSize = 13.sp)
                LabeledSlider("Volume", m.volume, 0f..2f, "${(m.volume * 100).toInt()}%",
                    { v -> vm.live { it.copy(music = it.music.map { x -> if (x.id == m.id) x.copy(volume = v) else x }) } }, vm::commit)
            }
            IconButton(onClick = { vm.edit { it.copy(music = it.music.filter { x -> x.id != m.id }) } }) { Icon(Icons.Default.Delete, "Remove") }
        }
    }
    Text("Not built yet: waveform, voiceover recording, audio extraction, fades, sound-effects library.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun FilterPanel(vm: EditorVM, p: Project) {
    Text("Colour filter (applied to the whole video on export)", fontSize = 12.sp, color = Muted)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FILTERS.forEach { f -> FilterChip(p.filter == f, { vm.edit { it.copy(filter = f) } }, { Text(f) }) }
    }
    Text("The live preview doesn't render filters yet; they are visible in the exported video.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun CanvasPanel(vm: EditorVM, p: Project) {
    Text("Aspect ratio", fontSize = 12.sp, color = Muted)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ASPECTS.forEach { a -> FilterChip(p.aspect == a, { vm.edit { it.copy(aspect = a) } }, { Text(a) }) }
    }
    Text("Clips are scaled to fill the frame and cropped to fit.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
}
