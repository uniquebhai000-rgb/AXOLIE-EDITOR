package com.axolie.editor.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString

@Entity(tableName = "projects")
data class ProjectEntity(@PrimaryKey val id: String, val name: String, val json: String, val updatedAt: Long)

@Entity(tableName = "exports")
data class ExportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectName: String,
    val uri: String,
    val createdAt: Long,
    val label: String,
)

@Dao
interface AxDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC") fun projects(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects WHERE id = :id") suspend fun project(id: String): ProjectEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(p: ProjectEntity)
    @Query("DELETE FROM projects WHERE id = :id") suspend fun delete(id: String)
    @Insert suspend fun addExport(e: ExportEntity)
    @Query("SELECT * FROM exports ORDER BY createdAt DESC LIMIT 30") fun exports(): Flow<List<ExportEntity>>
}

@Database(entities = [ProjectEntity::class, ExportEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AxDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "axolie.db").build().also { inst = it }
        }
    }
}

class Repo(ctx: Context) {
    val dao = AppDb.get(ctx).dao()

    suspend fun load(id: String): Project? =
        dao.project(id)?.let { runCatching { AppJson.decodeFromString<Project>(it.json) }.getOrNull() }

    suspend fun save(p: Project) {
        val np = p.copy(updatedAt = System.currentTimeMillis())
        dao.upsert(ProjectEntity(np.id, np.name, AppJson.encodeToString(np), np.updatedAt))
    }
}
