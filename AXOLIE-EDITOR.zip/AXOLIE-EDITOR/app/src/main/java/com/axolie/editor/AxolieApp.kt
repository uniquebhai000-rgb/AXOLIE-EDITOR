package com.axolie.editor

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.axolie.editor.export.ExportManager
import com.axolie.editor.export.ExportState

class AxolieApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_EXPORT, "Video export", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Export results", NotificationManager.IMPORTANCE_DEFAULT))
        // If the process died mid-export, the flag is still set: tell the UI honestly.
        val prefs = getSharedPreferences("export", MODE_PRIVATE)
        if (prefs.getString("running", null) != null) {
            prefs.edit().remove("running").apply()
            ExportManager.state.value = ExportState.Failed(
                "The last export was interrupted because Android closed the app. Please start it again."
            )
        }
    }

    companion object {
        const val CH_EXPORT = "export"
        const val CH_DONE = "export_done"
    }
}
