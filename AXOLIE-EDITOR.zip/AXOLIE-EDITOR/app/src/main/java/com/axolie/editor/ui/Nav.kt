package com.axolie.editor.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } }
        }
        composable("home") {
            HomeScreen(onOpen = { nav.navigate("editor/$it") }, onSettings = { nav.navigate("settings") })
        }
        composable("editor/{id}") { e ->
            val id = e.arguments?.getString("id") ?: return@composable
            EditorScreen(id, onBack = { nav.popBackStack() }, onExport = { nav.navigate("export/$id") })
        }
        composable("export/{id}") { e ->
            val id = e.arguments?.getString("id") ?: return@composable
            ExportScreen(id, onBack = { nav.popBackStack() })
        }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, androidx.compose.animation.core.tween(700)); delay(500); onDone() }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(Modifier.alpha(a.value).scale(0.8f + 0.2f * a.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(84.dp).clip(RoundedCornerShape(24.dp)).background(AxGradient), contentAlignment = Alignment.Center) {
                Text("A", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(Modifier.height(18.dp))
            Text("AXOLIE", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 6.sp)
            Text("EDITOR", fontSize = 14.sp, color = Muted, letterSpacing = 10.sp)
        }
    }
}
