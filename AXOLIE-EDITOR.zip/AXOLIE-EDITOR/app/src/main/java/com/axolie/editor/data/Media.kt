package com.axolie.editor.data

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Media {
    private val cache = LruCache<String, Bitmap>(48)

    suspend fun durationMs(ctx: Context, uri: String): Long = withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L } finally { runCatching { r.release() } }
    }

    suspend fun thumb(ctx: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(uri) ?: run {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, Uri.parse(uri))
                val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return@run null
                val w = 320
                val h = (f.height * (w / f.width.toFloat())).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(f, w, h, true).also { cache.put(uri, it) }
            } catch (e: Exception) { null } finally { runCatching { r.release() } }
        }
    }

    fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: "Clip"
}
