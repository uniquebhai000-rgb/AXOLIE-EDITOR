package com.axolie.editor.export

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object MediaStoreSaver {
    /** Copies [file] to a user-visible location and returns a content:// URI (or a file path on Android 8-9). */
    fun save(ctx: Context, file: File, displayName: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AXOLIE")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the output file in your gallery.")
            try {
                resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
            return uri.toString()
        }
        // Android 8-9: app-specific movies folder (no storage permission needed).
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AXOLIE").apply { mkdirs() }
        val out = File(dir, displayName)
        file.copyTo(out, overwrite = true)
        return out.absolutePath
    }
}
