package com.axolie.editor.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axolie.editor.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

class EditorVM(private val app: Application, val id: String) : AndroidViewModel(app) {
    private val repo = Repo(app)
    val project = MutableStateFlow<Project?>(null)
    val canUndo = MutableStateFlow(false)
    val canRedo = MutableStateFlow(false)
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    private val undo = ArrayDeque<Project>()
    private val redo = ArrayDeque<Project>()
    private var gestureBase: Project? = null
    private var saveJob: Job? = null
    private var commitJob: Job? = null

    init { viewModelScope.launch { project.value = repo.load(id) } }

    private fun flags() { canUndo.value = undo.isNotEmpty(); canRedo.value = redo.isNotEmpty() }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch { delay(500); project.value?.let { repo.save(it) } } // autosave
    }

    /** One undoable step. */
    fun edit(f: (Project) -> Project) {
        val cur = project.value ?: return
        commit()
        undo.addLast(cur); if (undo.size > 100) undo.removeFirst()
        redo.clear()
        project.value = f(cur); flags(); scheduleSave()
    }

    /** Continuous change (slider drag, typing). Grouped into one undo step on commit(). */
    fun live(f: (Project) -> Project) {
        val cur = project.value ?: return
        if (gestureBase == null) gestureBase = cur
        project.value = f(cur); scheduleSave()
        commitJob?.cancel()
        commitJob = viewModelScope.launch { delay(700); commit() }
    }

    fun commit() {
        commitJob?.cancel()
        gestureBase?.let { undo.addLast(it); redo.clear(); gestureBase = null; flags() }
    }

    fun undo() {
        commit()
        val cur = project.value ?: return
        val prev = undo.removeLastOrNull() ?: return
        redo.addLast(cur); project.value = prev; flags(); scheduleSave()
    }

    fun redo() {
        val cur = project.value ?: return
        val next = redo.removeLastOrNull() ?: return
        undo.addLast(cur); project.value = next; flags(); scheduleSave()
    }

    private fun persist(uri: Uri) {
        runCatching { app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    fun addVideos(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            busy.value = true
            val added = mutableListOf<Clip>()
            for (u in uris) {
                persist(u)
                val d = Media.durationMs(app, u.toString())
                if (d <= 0) { message.value = "Couldn't read \"${Media.displayName(app, u)}\". It may not be a supported video."; continue }
                added += Clip(uri = u.toString(), name = Media.displayName(app, u), durationMs = d)
            }
            if (added.isNotEmpty()) edit { it.copy(clips = it.clips + added) }
            busy.value = false
        }
    }

    fun addMusic(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            persist(uri)
            val d = Media.durationMs(app, uri.toString())
            if (d <= 0) message.value = "Couldn't read that audio file."
            else edit { it.copy(music = it.music + AudioTrack(uri = uri.toString(), name = Media.displayName(app, uri), durationMs = d)) }
            busy.value = false
        }
    }

    fun flush() { commit(); project.value?.let { p -> CoroutineScope(Dispatchers.IO).launch { repo.save(p) } } }

    override fun onCleared() { flush() }
}
