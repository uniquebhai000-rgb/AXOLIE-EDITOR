package com.axolie.editor.export

import android.content.Context
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import androidx.media3.common.AudioProcessor
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.axolie.editor.data.Project
import com.axolie.editor.data.TextLayer
import com.google.common.collect.ImmutableList

/** A text layer rendered by Media3 as a time-aware overlay on the composition timeline. */
class TimedText(private val t: TextLayer, private val frameH: Int) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        // A blank space (not empty) keeps the overlay bitmap non-zero-sized; alpha hides it.
        val s = SpannableString(t.text.ifBlank { " " })
        val n = s.length
        s.setSpan(ForegroundColorSpan(t.color), 0, n, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        if (Color.alpha(t.bgColor) > 0) s.setSpan(BackgroundColorSpan(t.bgColor), 0, n, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        val style = when { t.bold && t.italic -> Typeface.BOLD_ITALIC; t.bold -> Typeface.BOLD; t.italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
        s.setSpan(StyleSpan(style), 0, n, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        s.setSpan(AbsoluteSizeSpan((t.sizeFrac * frameH).toInt().coerceAtLeast(8)), 0, n, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val alpha = t.alphaAt(presentationTimeUs / 1000)
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(t.posX.coerceIn(0.05f, 0.95f) * 2f - 1f, 1f - t.posY.coerceIn(0.05f, 0.95f) * 2f)
            .setAlphaScale(alpha)
            .build()
    }
}

object Exporter {
    private fun volumeProcessor(v: Float): AudioProcessor = ChannelMixingAudioProcessor().apply {
        for (ch in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(v))
    }

    fun filterEffects(name: String): List<Effect> = when (name) {
        "Cinematic" -> listOf(Contrast(0.25f), RgbAdjustment.Builder().setRedScale(0.95f).setBlueScale(1.12f).build())
        "Vintage" -> listOf(HslAdjustment.Builder().adjustSaturation(-40f).build(), RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(0.85f).build())
        "Warm" -> listOf(RgbAdjustment.Builder().setRedScale(1.1f).setBlueScale(0.9f).build())
        "Cool" -> listOf(RgbAdjustment.Builder().setRedScale(0.9f).setBlueScale(1.1f).build())
        "B&W" -> listOf(RgbFilter.createGrayscaleFilter())
        "Contrast" -> listOf(Contrast(0.4f))
        "Bright" -> listOf(Brightness(0.15f))
        "Vivid" -> listOf(HslAdjustment.Builder().adjustSaturation(40f).build())
        else -> emptyList()
    }

    fun build(p: Project, o: ExportOptions): Composition {
        val (w, h) = ExportPlan.dims(p.aspect, o.shortSide)

        val items = p.clips.map { c ->
            val end = if (c.trimEndMs >= c.durationMs - 50) C.TIME_END_OF_SOURCE else c.trimEndMs
            val mi = MediaItem.Builder().setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.trimStartMs).setEndPositionMs(end).build()
                ).build()
            val audio = mutableListOf<AudioProcessor>()
            val video = mutableListOf<Effect>()
            if (c.speed != 1f) {
                audio += SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(1f) }
                video += SpeedChangeEffect(c.speed)
            }
            if (c.volume != 1f) audio += volumeProcessor(c.volume)
            if (c.rotation != 0 || c.flipH) {
                video += ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(c.rotation.toFloat())
                    .setScale(if (c.flipH) -1f else 1f, 1f).build()
            }
            EditedMediaItem.Builder(mi).setEffects(Effects(audio, video)).build()
        }
        val sequences = mutableListOf(EditedMediaItemSequence(items))

        val total = p.totalMs
        p.music.forEach { m ->
            val end = minOf(m.durationMs, total)
            val mi = MediaItem.Builder().setUri(m.uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setEndPositionMs(end).build())
                .build()
            val e = EditedMediaItem.Builder(mi).setRemoveVideo(true)
                .setEffects(Effects(listOf(volumeProcessor(m.volume)), emptyList())).build()
            sequences += EditedMediaItemSequence(listOf(e))
        }

        val compEffects = mutableListOf<Effect>()
        compEffects += Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        compEffects += filterEffects(p.filter)
        if (p.texts.isNotEmpty()) {
            compEffects += OverlayEffect(ImmutableList.copyOf(p.texts.map { TimedText(it, h) }))
        }
        return Composition.Builder(sequences).setEffects(Effects(emptyList(), compEffects)).build()
    }

    fun transformer(ctx: Context, o: ExportOptions, w: Int, h: Int, listener: Transformer.Listener): Transformer {
        val enc = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(ExportPlan.videoBitrate(w, h, o.hevc, o.quality)).build()
            ).build()
        return Transformer.Builder(ctx)
            .setVideoMimeType(if (o.hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(enc)
            .addListener(listener)
            .build()
    }
}
