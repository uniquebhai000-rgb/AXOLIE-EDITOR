package com.axolie.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.axolie.editor.ui.AppNav
import com.axolie.editor.ui.AxolieTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AxolieTheme { AppNav() } }
    }
}
