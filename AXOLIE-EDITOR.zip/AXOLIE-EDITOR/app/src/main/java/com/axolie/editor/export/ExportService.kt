package com.axolie.editor.export

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.axolie.editor.AxolieApp
import com.axolie.editor.MainActivity
import com.axolie.editor.R
import com.axolie.editor.data.AppDb
import com.axolie.editor.data.ExportEntity
import com.axolie.editor.data.Repo
import kotlinx.coroutines.*
import java.io.File

/**
 * Foreground service that owns the Transformer. Runs as a mediaProcessing FGS on Android 15+,
 * dataSync on Android 10-14, and a plain foreground service on Android 8-9.
 * It cannot survive force-stop, device shutdown or the system killing the process.
 */
class ExportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var temp: File? = null
    private var startedAt = 0L
    private var name = "Project"
    private var label = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> cancelExport()
            ACTION_START -> startExport(intent)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun foreground(n: Notification) {
        val type = when {
            Build.VERSION.SDK_INT >= 35 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun notif(text: String, percent: Int?): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, ExportService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, AxolieApp.CH_EXPORT)
            .setSmallIcon(R.drawable.ic_stat_export)
            .setContentTitle("Exporting $name")
            .setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Cancel", cancel)
        if (percent != null) b.setProgress(100, percent, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun startExport(i: Intent) {
        foreground(notif("Preparing…", null)) // must always be called after startForegroundService
        if (ExportManager.state.value is ExportState.Running) return // avoid duplicate exports

        val projectId = i.getStringExtra(X_PROJECT) ?: return finishWith(ExportState.Failed("No project given."), null, null)
        val opts = ExportOptions(i.getIntExtra(X_RES, 1080), i.getBooleanExtra(X_HEVC, false), i.getIntExtra(X_QUALITY, 1))
        label = "${opts.shortSide}p · ${if (opts.hevc) "HEVC" else "H.264"}"
        startedAt = System.currentTimeMillis()
        ExportManager.state.value = ExportState.Running(0, null, name) // set synchronously: blocks duplicates
        getSharedPreferences("export", MODE_PRIVATE).edit().putString("running", projectId).apply()

        scope.launch {
            val project = withContext(Dispatchers.IO) { Repo(this@ExportService).load(projectId) }
            if (project == null || project.clips.isEmpty()) {
                return@launch fail("This project has no clips to export.")
            }
            name = project.name

            val (w, h) = ExportPlan.dims(project.aspect, opts.shortSide)
            val need = ExportPlan.estimateBytes(project.totalMs, w, h, opts.hevc, opts.quality)
            if (StatFs(cacheDir.absolutePath).availableBytes < need * 13 / 10 + 50_000_000L) {
                return@launch fail("Not enough free storage to export. Free up some space and try again.")
            }
            val file = File(cacheDir, "export_${System.currentTimeMillis()}.mp4").also { temp = it }
            try {
                val t = Exporter.transformer(this@ExportService, opts, w, h, listener)
                transformer = t
                t.start(Exporter.build(project, opts), file.absolutePath)
                handler.post(ticker)
            } catch (e: Exception) {
                fail("Couldn't start the export: ${e.message ?: "unknown error"}")
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                val pct = holder.progress.coerceIn(0, 100)
                val elapsed = (System.currentTimeMillis() - startedAt) / 1000
                val eta = if (pct in 3..99) elapsed * (100 - pct) / pct else null
                ExportManager.state.value = ExportState.Running(pct, eta, name)
                val etaText = eta?.let { " · about ${it / 60}m ${it % 60}s left" } ?: ""
                (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager)
                    .notify(NOTIF_ID, notif("$pct%$etaText", pct))
            }
            handler.postDelayed(this, 500)
        }
    }

    private val listener = object : Transformer.Listener {
        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
            scope.launch {
                try {
                    val stamp = System.currentTimeMillis()
                    val uri = withContext(Dispatchers.IO) {
                        val u = MediaStoreSaver.save(this@ExportService, temp!!, "AXOLIE_$stamp.mp4")
                        AppDb.get(this@ExportService).dao().addExport(ExportEntity(projectName = name, uri = u, createdAt = stamp, label = label))
                        u
                    }
                    finishWith(ExportState.Done(uri, label), "Export finished", "$name was saved to Movies/AXOLIE")
                } catch (e: Exception) {
                    fail("The video was exported but couldn't be saved: ${e.message ?: "storage error"}")
                }
            }
        }

        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
            fail(human(exportException))
        }
    }

    private fun human(e: ExportException): String = when (e.errorCode) {
        ExportException.ERROR_CODE_IO_FILE_NOT_FOUND, ExportException.ERROR_CODE_IO_NO_PERMISSION ->
            "A source clip can't be read any more. It may have been moved or deleted. Re-import it and try again."
        ExportException.ERROR_CODE_ENCODER_INIT_FAILED, ExportException.ERROR_CODE_ENCODING_FORMAT_UNSUPPORTED ->
            "This device's encoder couldn't handle the chosen settings. Try 1080p or H.264."
        else -> "Export failed (${e.errorCodeName}). Try lower settings or remove the last clip you added."
    }

    private fun cancelExport() {
        transformer?.cancel()
        finishWith(ExportState.Cancelled, null, null)
    }

    private fun fail(msg: String) = finishWith(ExportState.Failed(msg), "Export failed", msg)

    private fun finishWith(state: ExportState, title: String?, text: String?) {
        handler.removeCallbacks(ticker)
        transformer = null
        temp?.delete(); temp = null
        getSharedPreferences("export", MODE_PRIVATE).edit().remove("running").apply()
        ExportManager.state.value = state
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        if (title != null) {
            val open = PendingIntent.getActivity(
                this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(this, AxolieApp.CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_export).setContentTitle(title).setContentText(text)
                .setAutoCancel(true).setContentIntent(open).build()
            (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).notify(NOTIF_ID + 1, n)
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel() // releases codecs if we're destroyed mid-export
        temp?.delete()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.axolie.editor.EXPORT_START"
        const val ACTION_CANCEL = "com.axolie.editor.EXPORT_CANCEL"
        const val X_PROJECT = "project"
        const val X_RES = "res"
        const val X_HEVC = "hevc"
        const val X_QUALITY = "quality"
        private const val NOTIF_ID = 1001

        fun start(ctx: android.content.Context, projectId: String, o: ExportOptions) {
            val i = Intent(ctx, ExportService::class.java).setAction(ACTION_START)
                .putExtra(X_PROJECT, projectId).putExtra(X_RES, o.shortSide)
                .putExtra(X_HEVC, o.hevc).putExtra(X_QUALITY, o.quality)
            androidx.core.content.ContextCompat.startForegroundService(ctx, i)
        }

        fun cancel(ctx: android.content.Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACTION_CANCEL))
        }
    }
}
