package com.axolie.editor.export

import kotlinx.coroutines.flow.MutableStateFlow

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val percent: Int, val etaSec: Long?, val projectName: String) : ExportState
    data class Done(val uri: String, val label: String) : ExportState
    data class Failed(val message: String) : ExportState
    data object Cancelled : ExportState
}

/** Process-wide export state, observed by the UI. The service is the only writer. */
object ExportManager {
    val state = MutableStateFlow<ExportState>(ExportState.Idle)
}

data class ExportOptions(val shortSide: Int, val hevc: Boolean, val quality: Int)
