package com.axolie.editor.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }
fun newId(): String = UUID.randomUUID().toString()

val ASPECTS = listOf("16:9", "9:16", "1:1", "4:5", "3:4")
fun aspectRatio(a: String): Float = when (a) {
    "9:16" -> 9f / 16f; "1:1" -> 1f; "4:5" -> 4f / 5f; "3:4" -> 3f / 4f; else -> 16f / 9f
}

val FILTERS = listOf("None", "Cinematic", "Vintage", "Warm", "Cool", "B&W", "Contrast", "Bright", "Vivid")

@Serializable
data class Clip(
    val id: String = newId(),
    val uri: String,
    val name: String,
    val durationMs: Long,
    val trimStartMs: Long = 0,
    val trimEndMs: Long = durationMs,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val rotation: Int = 0,
    val flipH: Boolean = false,
) {
    val effectiveMs: Long get() = maxOf(1L, ((trimEndMs - trimStartMs) / speed).toLong())
}

@Serializable
data class TextLayer(
    val id: String = newId(),
    val text: String = "Your text",
    val startMs: Long = 0,
    val durationMs: Long = 3000,
    val color: Int = -1,
    val bgColor: Int = 0,
    val sizeFrac: Float = 0.07f,
    val bold: Boolean = true,
    val italic: Boolean = false,
    val posX: Float = 0.5f,
    val posY: Float = 0.8f,
    val opacity: Float = 1f,
    val style: String = "Classic",
    val animation: String = "None",
) {
    /** Opacity at a timeline time; 0 when the layer is not visible. Used by preview AND export. */
    fun alphaAt(ms: Long): Float {
        if (ms < startMs || ms >= startMs + durationMs) return 0f
        var a = opacity
        if (animation == "Fade") {
            val f = minOf(1f, (ms - startMs) / 400f, (startMs + durationMs - ms) / 400f)
            a *= f.coerceIn(0f, 1f)
        }
        return a
    }
}

@Serializable
data class AudioTrack(
    val id: String = newId(),
    val uri: String,
    val name: String,
    val durationMs: Long,
    val volume: Float = 1f,
)

@Serializable
data class Project(
    val id: String = newId(),
    val name: String,
    val clips: List<Clip> = emptyList(),
    val texts: List<TextLayer> = emptyList(),
    val music: List<AudioTrack> = emptyList(),
    val filter: String = "None",
    val aspect: String = "16:9",
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val totalMs: Long get() = clips.sumOf { it.effectiveMs }
    fun startOf(index: Int): Long = clips.take(index).sumOf { it.effectiveMs }

    /** Timeline ms -> (clip index, source offset from the clip's trim start). */
    fun locate(ms: Long): Pair<Int, Long> {
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            val e = c.effectiveMs
            if (ms < acc + e) return i to ((ms - acc) * c.speed).toLong()
            acc += e
        }
        val last = clips.lastIndex
        return last to (clips.lastOrNull()?.let { it.trimEndMs - it.trimStartMs } ?: 0L)
    }

    fun mapClip(index: Int, f: (Clip) -> Clip) =
        copy(clips = clips.mapIndexed { i, c -> if (i == index) f(c) else c })

    fun mapText(id: String, f: (TextLayer) -> TextLayer) =
        copy(texts = texts.map { if (it.id == id) f(it) else it })
}
