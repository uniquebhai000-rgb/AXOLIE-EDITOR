# AXOLIE EDITOR (stage 1 MVP)

Native Android video editor: Kotlin, Jetpack Compose, Material 3, Media3 (ExoPlayer preview + Transformer export), Room, DataStore.

> **Status: source complete for stage 1, NOT yet compiled or run by the author.**
> It was written without network access, so Gradle could not download dependencies. Expect a few compile
> errors on the first build (most likely in Media3 API names). Fix them or send me the log from GitHub Actions.

## Build

### GitHub Actions (APK)
1. Push this folder to a GitHub repo (branch `main`).
2. Open **Actions → Android Debug Build** (also runnable via *Run workflow*).
3. Download artifact **AXOLIE-EDITOR-debug-apk** → `AXOLIE-EDITOR-debug-<n>.apk`.
4. Enable "install unknown apps" on your phone and install it.

### Android Studio
Open the folder (Android Studio Koala+ / JDK 17). It downloads Gradle 8.9 from `gradle-wrapper.properties`.
The wrapper JAR/scripts are not included (binary, could not be generated offline). To add them once:
`gradle wrapper --gradle-version 8.9`, or just build from Android Studio / the workflow.

## What works in stage 1 (by design)
- Projects: create, rename, duplicate, delete, autosave, reopen, thumbnails, last-edited date, export history.
- Import videos (Storage Access Framework, persisted permission), multiple clips.
- Timeline: trim (range slider), split at playhead, duplicate, delete, reorder, speed, volume, rotate, flip, zoom, scrub, play/pause, undo/redo.
- Canvas: 16:9, 9:16, 1:1, 4:5, 3:4 (fill + crop).
- Text: multiple layers, 6 style presets with previews, colour, background, bold/italic, size, position, opacity, start/duration, fade animation. Rendered into the export via Media3 overlays.
- Audio: add background music tracks, per-track volume (trimmed to video length).
- Filters (applied on export): Cinematic, Vintage, Warm, Cool, B&W, Contrast, Bright, Vivid.
- Export: 720p/1080p/4K and H.264/HEVC enabled only if the device encoder reports support; quality presets; size estimate; output to `Movies/AXOLIE`.
- Background export: foreground service (`mediaProcessing` on Android 15+, `dataSync` on 10-14, plain FGS on 8-9), progress + ETA notification, Cancel action, completion/error notifications, duplicate-export guard, low-storage check, interrupted-export detection after process death.

## Not built yet (nothing in the UI pretends otherwise)
Image clips, overlays/PiP, chroma key, keyframes, transitions, effects (glow, glitch, etc.), freeze frame, reverse,
most text animations (only fade), custom fonts/stroke/shadow/gradient, voiceover, audio extraction, waveform, fades,
sound effects, AI studio (prompt + automatic), auto captions/SRT, FPS selection, audio bitrate, custom output folder,
WorkManager fallback, light theme, live filter preview.

## Limits (honest)
- Export cannot survive force-stop, shutdown, or the OS killing the process. After such a kill the app tells you the export was interrupted.
- Android 15 limits some foreground-service types; mediaProcessing has its own time limits set by the OS.
- Clips with and without audio mixed in one project may fail on Media3 1.3.1; the error is shown in readable form.
- Speed changes use Media3 `SpeedChangeEffect` + Sonic audio; verify A/V sync on your device.

## Stage 2 plan
Transitions + image clips, overlays/PiP, more text styling and animations, audio waveform/voiceover, SRT + captions, then the AI provider interface (configurable endpoint, no keys in the APK).
